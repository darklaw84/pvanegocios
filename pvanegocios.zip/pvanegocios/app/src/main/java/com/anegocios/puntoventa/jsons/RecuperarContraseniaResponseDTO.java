package com.anegocios.puntoventa.jsons;

public class RecuperarContraseniaResponseDTO {
    private String msg;
    private boolean exito;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isExito() {
        return exito;
    }

    public void setExito(boolean exito) {
        this.exito = exito;
    }
}
