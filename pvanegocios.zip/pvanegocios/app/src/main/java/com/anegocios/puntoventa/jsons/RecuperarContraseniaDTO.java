package com.anegocios.puntoventa.jsons;

public class RecuperarContraseniaDTO {

    private String username;

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
