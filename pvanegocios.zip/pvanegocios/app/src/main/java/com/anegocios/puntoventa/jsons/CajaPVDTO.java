package com.anegocios.puntoventa.jsons;

public class CajaPVDTO {

    private String fechaInicio;
    private int idUT;

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public int getIdUT() {
        return idUT;
    }

    public void setIdUT(int idUT) {
        this.idUT = idUT;
    }
}
