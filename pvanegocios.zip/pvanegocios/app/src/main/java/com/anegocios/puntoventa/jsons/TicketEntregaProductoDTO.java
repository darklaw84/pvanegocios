package com.anegocios.puntoventa.jsons;

public class TicketEntregaProductoDTO {

    private int id;
    private String folioApp;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFolioApp() {
        return folioApp;
    }

    public void setFolioApp(String folioApp) {
        this.folioApp = folioApp;
    }
}
